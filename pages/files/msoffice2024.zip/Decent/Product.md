<Product>			-	<availability>



* Access			-	<yes>
* Skype for Business		-	<no>
* OneNote			-	<yes>
* PowerPoint			-	<yes>
* Word				-	<yes>
* Excel				-	<yes>
* OneDrive Desktop		-	<yes>
* Outlook (classic)		-	<no>
* Publisher			-	<no>
