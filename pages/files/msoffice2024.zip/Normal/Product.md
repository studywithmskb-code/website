<Product>			-	<availability>



* Access			-	<no>
* Skype for Business		-	<no>
* OneNote			-	<no>
* PowerPoint			-	<yes>
* Word				-	<yes>
* Excel				-	<yes>
* OneDrive Desktop		-	<no>
* Outlook (classic)		-	<no>
* Publisher			-	<no>
